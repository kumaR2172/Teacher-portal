import { useState } from "react";

function First(){
    const[name, setName]=useState("Abhishek")
    const[address, setAddress]=useState("Bareilly")

    const handleChange=()=>{
        setAddress("CHD")
    }
    return(
        <div>
            Name:{name}<br/>
            <button onClick={()=>setName("Abhi")}>Change Name</button><br/>
            Address:{address}<br/>
            <button onClick={handleChange}> Change Address</button>
        </div>
    )
}

export default First;