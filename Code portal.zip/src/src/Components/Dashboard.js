
function DashBoard(){
    return(
<div>     
<h1>Welcome Abhishek</h1>
<p>Your Name:- Abhishek Pandey<br/>
    Your Age:- 21
    Your Address:- Bareilly</p>

</div>
    );
}
export default DashBoard;
