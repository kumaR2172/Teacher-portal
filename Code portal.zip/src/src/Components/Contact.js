const Contact=()=>{
    return(
        <>
        <h4>Call us at: 8956432109</h4>
        <h3>Email us at : abc@gmail.com</h3>
        </>
    )
}

export default Contact;