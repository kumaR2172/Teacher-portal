import {TextField,Grid,Box} from "@mui/material";
import { useNavigate } from 'react-router-dom';
import {useState} from 'react';




function Login(){
    
    let navigate = useNavigate();
    const [name,setName] = useState("")
    const [pwd, setPwd] = useState("")   
    const [message,setMessage] = useState("") 

    const handleLogin = (e) => {
        e.preventDefault();
        if((name==="Abhishek") && (pwd==="7895"))
        { 
            navigate('/homepage'); 
        }
        else
        { 
           
           setMessage("Invalid Username or Password!")
        }
    }

    
    
    return(
        <div className="Login-div">
    <form onSubmit={handleLogin}>

        <h2>Login</h2>
<Box sx={{ flexGrow: 1 }}>
    <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField type="text" placeholder="Enter your name" variant="outlined"  onChange={(event)=>setName(event.target.value)}/>
        </Grid>
        <Grid item xs={12}>
            <TextField type="password" placeholder="Enter your password" variant="outlined" onChange={(event)=>setPwd(event.target.value)}/>
        </Grid>
        <Grid item xs={12}>
            
       
        <div className="text-danger">{message}</div>
        <button type="submit" className="btn btn-primary">Login</button>
            
        </Grid>
  
    </Grid>
  </Box>
    
    </form>
    </div>
    )
}
export default Login;



