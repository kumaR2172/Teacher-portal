import React from 'react';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import HomePage from './HomePage';
import Home from './Home';
import About from './About';
import Contact from './Contact';
import First from './First';
import Login from './Login';
import Header from './Header';
import Dashboard from './Dashboard';
function Router()
  {
    return(
    <BrowserRouter>
  <Routes>
      <Route path="/" element={<Login/>}/>
      <Route path="homepage" element={<HomePage/>}>
      <Route path="home" index element={<Home/>}/> 
      <Route path="about" element={<About/>}/>
      <Route path="contact" element={<Contact/>}/>
      <Route path="first" element={<First/>}/>
      <Route path="header" element={<Header/>}/>
      <Route path="dashboard" element={<Dashboard/>}/></Route>
      
       
    </Routes>
    </BrowserRouter> 
    );
  }
export default Router;