import { Link,Outlet } from "react-router-dom";
import './Header.css';

const Header=()=>{
    return(
        <div>
        <h3 className="header">Inside Header 
            <br/><br/>
        <nav className="nav-bar">
        <li className="nav-item">
          <Link  classname="active" to="contact">Contact</Link> {" "}

          </li>
            <Outlet/>
        </nav>
        </h3>
        </div>

    );
}

export default Header;