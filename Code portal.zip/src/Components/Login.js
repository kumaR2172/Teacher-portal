import React, {useState } from "react"
import axios from "axios"
import './form.css';
import { useNavigate, Link } from "react-router-dom"


function Login() {

    const history=useNavigate();

    const [email,setEmail]=useState('')
    const [password,setPassword]=useState('')

    async function submit(e){
        e.preventDefault();

        try{

            await axios.post("http://localhost:8000/",{
                email,password
            })
            .then(res=>{
                if(res.data==="exist"){
                    history("/home",{state:{id:email}})
                }
                else if(res.data==="notexist"){
                    alert("User have not sign up")
                }
            })
            .catch(e=>{
                alert("wrong details")
                console.log(e);
            })

        }
        catch(e){
            console.log(e);

        }

    }


    return (
        <div>

            <h1><center>Login Page</center></h1>
            <div class="formDiv">
            <form action="POST">
                <input type="email" class="form-control" onChange={(e) => { setEmail(e.target.value) }} placeholder="Email"  /><br></br>
                <input type="password" class="form-control" onChange={(e) => { setPassword(e.target.value) }} placeholder="Password"  /><br></br>
                <input type="submit" className="btn btn-primary mx-2" onClick={submit} />

            </form>
           </div>
            

            <h4><center><Link to="/signup">Signup Page</Link></center></h4>

        </div>
    )
}

export default Login