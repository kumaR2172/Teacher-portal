

//import { BsFillTrashFill, BsFillPencilFill } from "react-icons/bs";

import Modal from 'react-modal';
import React,{useEffect,useState} from "react";
import axios from 'axios';
import {useLocation} from 'react-router-dom';


function Home() {
    const[data,setData]=useState([]);
    const[name,setName]=useState('');
    const[subject,setSubject]=useState('');
    const[marks,setMarks]=useState('');

    const[uname,usetName]=useState('');
    const[usubject,usetSubject]=useState('');
    const[umarks,usetMarks]=useState('');
    const[editId,setEditID]=useState(-1);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const location=useLocation();


    
  useEffect(()=>{
    axios.get('http://localhost:3000/student')
    .then(res=> setData(res.data))
    .catch(er=>console.log(er))
  },[])

  const handleSubmit=(event)=>{
    event.preventDefault();
    const id = data.length + 1; 
    setIsModalOpen(false);
    axios.post('http://localhost:3000/student', {id:id, name:name,subject:subject, marks:marks})
    .then(res=>{
        location.reload()
    })
    .catch(er=>console.log(er));

  }

  const handleEdit=(id)=>{
    axios.get('http://localhost:3000/student/'+id)
    .then(res=>{
        console.log(res.data)
        usetName(res.data.name)
        usetSubject(res.data.subject)
        usetMarks(res.data.marks)
    }).catch(er=>console.log(er))
    setEditID(id);
    

  }
  const handleUpdate = ()=>{
    axios.put('http://localhost:3000/student/'+editId,{id:editId,name:uname,subject:usubject,marks:umarks})
    .then(res=>{
        console.log(res);
        location.reload();
        setEditID(-1);
    }).catch(err=>console.log(err));
  }

  const handleDelete = (id)=>{
    alert("deleted");
    axios.delete('http://localhost:3000/student/'+id)
    .then(res=>{
        location.reload();
    }).catch(err=>console.log(err));
  }

  return(
    <>
    <div className="card">
        <div className="card-header">
            <h4>Students List</h4>
            <button className="btn btn-primary mx-2"  onClick={() => setIsModalOpen(true)}>Add Student</button>
            <form onSubmit={handleSubmit}>
            <Modal isOpen={isModalOpen} onRequestClose={() => setIsModalOpen(false)}>
                <div class="container">
                <h2>Add New Student</h2>
                <input type="text" placeholder="Name" onChange={e=>setName(e.target.value)} />
                <input type="text" placeholder="Subject" onChange={e=>setSubject(e.target.value)} />
                <input placeholder="Marks" type="number" onChange={e=>setMarks(e.target.value)} />
                <button className="btn btn-primary mx-2"  onClick={handleSubmit}>Add</button>
                <button onClick={() => setIsModalOpen(false)}>Close</button>
                </div>
            </Modal>
            </form>
        </div>
    </div>

    <div className="container">
        
<table>
    <thead>
        <tr>
            <th>Id</th> 
            <th>Name</th>
            <th>Subject</th>
            <th>Marks</th>
            <th>Edit</th>
            <th>Delete</th>
            
        </tr>
    </thead>
    <tbody>
        {
     data.map((student,index) => (

          student.id === editId ?
          <tr>
            <td>{student.id}</td>
            <td><input type="text" value={uname} onChange={e=>usetName(e.target.value)}/></td>
            <td><input type="text" value={usubject} onChange={e=>usetSubject(e.target.value)}/></td>
            <td><input type="text" value={umarks} onChange={e=>usetMarks(e.target.value)}/></td>
            <td><button onClick={handleUpdate}>update</button></td>
          </tr>
        :
        <tr key={index}>
            <td>{student.id}</td> 
            <td>{student.name}</td>
            <td>{student.subject}</td>
            <td>{student.marks}</td>
            <td><button className="btn btn-primary mx-2"  onClick={() => handleEdit(student.id)}>Edit</button></td>
            <td><button className="btn btn-primary mx-2"  onClick={() => handleDelete(student.id)}>Delete</button></td>
        </tr>

     ))
    }
    </tbody>
</table>
    </div>
    </>
  )
    
  }

  export default Home;